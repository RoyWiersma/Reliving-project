import { useState } from 'react';

import './App.css';
import 'bootstrap/dist/css/bootstrap.css';

function App() {
  const [name, setName] = useState('');
  const [street, setStreet] = useState('');
  const [housenumber, setHousenumber] = useState('');
  const [extension, setExtension] = useState('');
  const [zipcode, setZipcode] = useState('');
  const [city, setCity] = useState('');
  let [country, setCountry] = useState('');

  const handleSubmit = e => {
    e.preventDefault();
    if (country === "Belgium"){
      alert("Gij komt uit Belgie")
    }
    else {
      alert("Jij komt uit Nederland")
    }
    console.log('Form was submitted');
  }

  return (
    <div className="container">
      <section>
        <h1>Address form</h1>      
        <form onSubmit={handleSubmit} className="row g-3">
          <div className="row">
          <label>Name</label>
          <input type="text" className="form-control" value={name} onChange={e => setName(e.target.value)} required={true}/>
          </div>
          <div className="row">
            <div className="col-md-6">
              <label>Street</label>
              <input type="text" className="form-control" aria-label="First name" value={street} onChange={e => setStreet(e.target.value)} required={true}/>
            </div>
            <div className="col-md-4">
              <label>Housenumber</label>
              <input type="text" className="form-control"aria-label="Last name" value={housenumber} onChange={e => setHousenumber(e.target.value)} required={true}/>
            </div>
            <div className="col-md-2">
              <label>Extension</label>
              <input type="text" className="form-control" aria-label="Last name" value={extension} onChange={e => setExtension(e.target.value)} />
          </div>
          </div>
          <div className="row">
          <label>Zipcode</label>
          <input type="text" className="form-control" value={zipcode} onChange={e => setZipcode(e.target.value)} required={true}/>
          </div>
          <div className="row">
          <label>City</label>
          <input type="text" className="form-control" value={city} onChange={e => setCity(e.target.value)} required={true}/>
          </div>
          <div className="row">
          <label>Country</label>
          <select  className="form-control" value={country} onChange={e => setCountry(e.target.value)}>
            <option value='Belgium'>Belgium</option>
            <option value='Netherlands'>Netherlands</option>
          </select>
          </div>
            <input type="submit" value="Submit" />
        </form>
      </section>
    </div>
  );
}

export default App;
