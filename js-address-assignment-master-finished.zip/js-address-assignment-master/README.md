# Reliving JavaScript assignment

At Reliving we have lots of customers filling out their Address details in an online form. Too often, customers forget to enter their house number, making it complicated and time intensive for us to fulfill their order.

# Fix the address form

We would like you to demonstrate how we could improve our address form so that we won't receive any more addresses that are missing house numbers.

We have setup a small boilerplate you can use as a starting point. This uses the [React library](https://reactjs.org) to load a basic and quite naive address form.

Please demonstrate the following:

1. Change the `country` input field into a select field with `Netherlands` and `Belgium` as options
2. Make sure that the user cannot submit a form with empty fields.
3. Split up the `address` field in seperate fields for street, house number and house number extention.
4. Use css to make sure that the three new fields are nicely aligned horizontally (aka on one line)
5. Ensure that street and house number are required. The house number extention should not be required.
6. After the form submission, if all fields are valid, show the user the an `alert` with a message.

If the selected `country` is `Belgium`, show:

```
Gij komt uit Belgie 🇧🇪🇧🇪🇧🇪
```

If the selected `country` is `Netherlands`, show:

```
Jij komt uit Nederland 🇳🇱🇳🇱🇳🇱
```

# Requirements

- Node >= 6

# Running the application

1. Clone this repository
2. Run the application via `npm` or `yarn`

### yarn

```
yarn && yarn start
```

### npm

```
npm install && npm start
```

You should see something like:

![Screenshot 2022-01-11 at 17 16 43](https://user-images.githubusercontent.com/431685/148990222-24db888c-b101-4d7d-9a24-d8f32a9bed48.png)

